package cs3714.hw4.interfaces;

/**
 * Created by Andrey on 3/1/2017.
 */

public interface LogInScreenInteraction {

    void LoginStatus(String status);
    void NetworkingFlagUpdate(Boolean busyNetworking);
}
